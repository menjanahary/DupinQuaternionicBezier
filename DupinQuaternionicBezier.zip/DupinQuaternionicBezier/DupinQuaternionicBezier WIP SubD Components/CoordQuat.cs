﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class CoordQuatComponent : GH_Component
    {
        private Quaternion q;
        private List<double> xyz;
        public CoordQuatComponent()
          : base(
                "Coordinates",
                "Coord",
                "Components of a quaternion number",
                "DupinQuaternionicBezier",
                " Tools")
        {
            q = new Quaternion();
            xyz = new List<double>();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("A quaternion", "q", "A quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("Coord", "Coord", "The coordinates of a purely imaginary quaternion", GH_ParamAccess.list);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q);
            //
            xyz.Clear();
            xyz.Add(q.B);
            xyz.Add(q.C);
            xyz.Add(q.D);
            //
            DA.SetDataList(0, xyz);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.coord;
            }
        }
        public override Guid ComponentGuid => new Guid("6b1674d6-b83c-4efd-abb0-4108f44c7ebb");
    }
}