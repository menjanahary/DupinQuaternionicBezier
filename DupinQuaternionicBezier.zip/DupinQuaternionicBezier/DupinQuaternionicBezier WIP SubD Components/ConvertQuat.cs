﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class ConvertQuatComponent : GH_Component
    {
        private Point3d P;
        public ConvertQuatComponent()
          : base(
                "ConvertQuat",
                "ConvQuat",
                "Convert a Point3d to a quaternion number",
                "DupinQuaternionicBezier",
                " Tools")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("P", "P", "A 3d point", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Quaternion", "q", "The resulting quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref P);
            //
            Quaternion q = new Quaternion(0, P.X, P.Y, P.Z);
            //
            DA.SetData(0, q);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.convertQuat;
            }
        }
        public override Guid ComponentGuid => new Guid("c4431171-ca0a-4f85-98b3-227afcd94199");
    }
}