﻿using Grasshopper;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Types;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class DupinMeshComponent : GH_Component
    {
        private Point3d P0;
        private Point3d P1;
        private Point3d P2;
        private Point3d P3;
        private Vector3d V01;
        private Vector3d V02;
        private double repS;
        private double repT;
        public DupinMeshComponent()
          : base(
                "DupinMesh",
                "DuMesh",
                "Mesh representation of a Dupin cyclide principal patch",
                "DupinQuaternionicBezier",
                "Meshes")
        {
            P0 = new Point3d();
            P1 = new Point3d();
            P2 = new Point3d();
            P3 = new Point3d();
            V01 = new Vector3d();
            V02 = new Vector3d();
            repS = 0.0;
            repT = 0.0;
        }
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("P0", "P0", "First generic point", GH_ParamAccess.item);
            pManager.AddPointParameter("P1", "P1", "Second generic point", GH_ParamAccess.item);
            pManager.AddPointParameter("P2", "P2", "Third generic point", GH_ParamAccess.item);
            pManager.AddPointParameter("P3", "P3", "Circle generic point", GH_ParamAccess.item);
            pManager.AddVectorParameter("v01", "v01", "Direction of arc P0P1", GH_ParamAccess.item);
            pManager.AddVectorParameter("v02", "v02", "Direction of arc P0P2", GH_ParamAccess.item);
            pManager.AddNumberParameter("repS", "repS", "Reparametrization parameter in the s direction", GH_ParamAccess.item);
            pManager.AddNumberParameter("repT", "repT", "Reparametrization parameter in the t direction", GH_ParamAccess.item);
            pManager.AddIntegerParameter("U Count", "U", "Number of divisions in U direction", GH_ParamAccess.item, 10);
            pManager.AddIntegerParameter("V Count", "V", "Number of divisions in V direction", GH_ParamAccess.item, 10);
         }
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddMeshParameter("Mesh", "M", "Generated triangulated mesh", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            int uCount = 10;
            int vCount = 10;

            DA.GetData(0, ref P0);
            DA.GetData(1, ref P1);
            DA.GetData(2, ref P2);
            DA.GetData(3, ref P3);
            DA.GetData(4, ref V01);
            DA.GetData(5, ref V02);
            DA.GetData(6, ref repS);
            DA.GetData(7, ref repT);
            //
            if (!DA.GetData(8, ref uCount)) return;
            if (!DA.GetData(9, ref vCount)) return;
            //
            Quaternion p0 = new Quaternion(0, P0.X, P0.Y, P0.Z);
            Quaternion p1 = new Quaternion(0, P1.X, P1.Y, P1.Z);
            Quaternion p2 = new Quaternion(0, P2.X, P2.Y, P2.Z);
            Quaternion p3 = new Quaternion(0, P3.X, P3.Y, P3.Z);
            Quaternion v01 = new Quaternion(0, V01.X, V01.Y, V01.Z);
            Quaternion v02 = new Quaternion(0, V02.X, V02.Y, V02.Z);
            //
            // Create a list to hold the mesh vertices
            List<Point3d> vertices = new List<Point3d>();

            // Create the grid of vertices
            for (int v = 0; v < vCount; v++)
            {
                for (int u = 0; u < uCount; u++)
                {
                    double ss =  Convert.ToDouble(u)/ (Convert.ToDouble(uCount) - 1.0);
                    double tt = Convert.ToDouble(v) / (Convert.ToDouble(vCount) - 1.0);
                    Quaternion quaternion = qBezier(p0, p1, p2, p3, v01, v02, ss, tt, repS, repT);
                    Point3d point = new Point3d(quaternion.B, quaternion.C, quaternion.D);
                    vertices.Add(point);
                }
            }
            // Create the mesh faces (two triangles per grid cell)
            List<MeshFace> faces = new List<MeshFace>();
            for (int v = 0; v < vCount - 1; v++)
            {
                for (int u = 0; u < uCount - 1; u++)
                {
                    int index0 = u + v * uCount;
                    int index1 = (u + 1) + v * uCount;
                    int index2 = u + (v + 1) * uCount;
                    int index3 = (u + 1) + (v + 1) * uCount;
                    // First triangle
                    faces.Add(new MeshFace(index0, index1, index2));
                    // Second triangle
                    faces.Add(new MeshFace(index1, index3, index2));
                }
            }
            // Create the mesh and set the vertices and faces
            Mesh mesh = new Mesh();
            mesh.Vertices.AddVertices(vertices);
            mesh.Faces.AddFaces(faces);

            // Output the generated mesh
            DA.SetData(0, new GH_Mesh(mesh));
        }

        private Quaternion qBezier(Quaternion p0, Quaternion p1, Quaternion p2, Quaternion p3, Quaternion v01, Quaternion v02, double s, double t, double repS, double repT)
        {
            Quaternion Id = new Quaternion(1, 0, 0, 0);
            Quaternion w1 = (p1 - p0).Inverse * v01 * repS;
            Quaternion w2 = (p2 - p0).Inverse * v02 * repT;
            Quaternion w3 = (p3 - p0).Inverse * ((p1 - p0).Inverse - (p2 - p0).Inverse) * v01 * v02 * repS * repT;
            Quaternion num = (p0 * (1 - s) + p1 * w1 * s) * (1 - t) + (p2 * w2 * (1 - s) + p3 * w3 * s) * t;
            Quaternion den = (Id * (1 - s) + w1 * s) * (1 - t) + (w2 * (1 - s) + w3 * s) * t;
            Quaternion circ = num * den.Inverse;
            return circ;
        }
        protected override System.Drawing.Bitmap Icon => null;
        public override Guid ComponentGuid => new Guid("99cb7309-f72b-48f3-89d5-3c57bd14f576");
    }
}