﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class ReflectionWrtEdgeComponent : GH_Component
    {
        private Point3d P0;
        private Point3d P1;
        private Vector3d V01;
        public ReflectionWrtEdgeComponent()
          : base(
                " ReflectEdge",
                "Reflec",
                "Reflect a vector with respect to an edge",
                "DupinQuaternionicBezier",
                " Tools")
        {
            P0 = new Point3d();
            P1 = new Point3d();
            V01 = new Vector3d();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("Start Point", "S", "Start point of the edge", GH_ParamAccess.item);
            pManager.AddPointParameter("End Point", "E", "End point of the edge", GH_ParamAccess.item);
            pManager.AddVectorParameter("Vector", "D", "The vector to reflect", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddVectorParameter("Vector", "Vec", "The reflected vector", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref P0);
            DA.GetData(1, ref P1);
            DA.GetData(2, ref V01);
            //
            Quaternion p0 = new Quaternion(0, P0.X, P0.Y, P0.Z);
            Quaternion p1 = new Quaternion(0, P1.X, P1.Y, P1.Z);
            Quaternion v01 = new Quaternion(0, V01.X, V01.Y, V01.Z);
            //
            Quaternion q = (p0 - p1) * v01 * (p1 - p0).Inverse;
            //
            Vector3d Vf = new Vector3d(q.B, q.C, q.D);
            //
            DA.SetData(0, Vf);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.reflec;
            }
        }
        public override Guid ComponentGuid => new Guid("805a9bc5-5a9b-413c-a130-ee93aafc5833");
    }
}