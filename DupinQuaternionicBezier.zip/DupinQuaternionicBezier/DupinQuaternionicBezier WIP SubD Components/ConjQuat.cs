﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class ConjQuatComponent : GH_Component
    {
        private Quaternion q;
        public ConjQuatComponent()
          : base(
                "ConjugateQuat",
                "Conj",
                "Conjugate of a quaternion number",
                "DupinQuaternionicBezier",
                " Tools")
        {
            q = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("A quaternion", "q", "A quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Inverse", "q", "The inverse quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q);
            //
            Quaternion cq = q.Conjugate;
            //
            DA.SetData(0, cq);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.conjug;
            }
        }
        public override Guid ComponentGuid => new Guid("996601a3-785a-453d-b327-7bc27564cbc5");
    }
}