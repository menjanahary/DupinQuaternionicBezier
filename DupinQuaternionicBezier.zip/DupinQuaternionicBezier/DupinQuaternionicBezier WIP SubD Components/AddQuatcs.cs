﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class AddQuatComponent : GH_Component
    {
        private Quaternion q1;
        private Quaternion q2;
        public AddQuatComponent()
          : base(
                "   AddQuat",
                "Add",
                "Add two quaternion numbers",
                "DupinQuaternionicBezier",
                " Operations")
        {
            q1 = new Quaternion();
            q2 = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("First quaternion", "q1", "First quaternion", GH_ParamAccess.item);
            pManager.AddGenericParameter("Second quaternion", "q2", "Second quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Quaternion", "q", "The resulting quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q1);
            DA.GetData(1, ref q2);
            //
            Quaternion q = q1 + q2;
            //
            DA.SetData(0, q);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.add;
            }
        }
        public override Guid ComponentGuid => new Guid("0941562d-3161-44f3-ad04-341fad2e8b57");
    }
}