﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class GetDupinPointComponent : GH_Component
    {
        private Point3d point;
        private Point3d P0;
        private Point3d P1;
        private Point3d P2;
        private Point3d P3;
        private Vector3d V01;
        private Vector3d V02;
        private double repS;
        private double repT;
        private double s;
        private double t;
        public GetDupinPointComponent()
          : base(
                "DupinPoint",
                "DuPt",
                "A point on a Dupin cyclide principal patch",
                "DupinQuaternionicBezier",
                "Patches")
        {
            point = new Point3d();
            P0 = new Point3d();
            P1 = new Point3d();
            P2 = new Point3d();
            P3 = new Point3d();
            V01 = new Vector3d();
            V02 = new Vector3d();
            repS = 0.0;
            repT = 0.0;
            s = 0.0;
            t = 0.0;
        }
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("P0", "P0", "First generic point", GH_ParamAccess.item);
            pManager.AddPointParameter("P1", "P1", "Second generic point", GH_ParamAccess.item);
            pManager.AddPointParameter("P2", "P2", "Third generic point", GH_ParamAccess.item);
            pManager.AddPointParameter("P3", "P3", "Circle generic point", GH_ParamAccess.item);
            pManager.AddVectorParameter("v01", "v01", "Direction of arc P0P1", GH_ParamAccess.item);
            pManager.AddVectorParameter("v02", "v02", "Direction of arc P0P2", GH_ParamAccess.item);
            pManager.AddNumberParameter("repS", "repS", "Reparametrization parameter in the s direction", GH_ParamAccess.item);
            pManager.AddNumberParameter("repT", "repT", "Reparametrization parameter in the t direction", GH_ParamAccess.item);
            pManager.AddNumberParameter("s", "s", "A value in s direction", GH_ParamAccess.item);
            pManager.AddNumberParameter("t", "t", "A value in t direction", GH_ParamAccess.item);
        }
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddPointParameter("DupinPoint", "DuPt", "A point on the Dupin cyclide principal patch", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref P0);
            DA.GetData(1, ref P1);
            DA.GetData(2, ref P2);
            DA.GetData(3, ref P3);
            DA.GetData(4, ref V01);
            DA.GetData(5, ref V02);
            DA.GetData(6, ref repS);
            DA.GetData(7, ref repT);
            DA.GetData(8, ref s);
            DA.GetData(9, ref t);
            //
            Quaternion p0 = new Quaternion(0, P0.X, P0.Y, P0.Z);
            Quaternion p1 = new Quaternion(0, P1.X, P1.Y, P1.Z);
            Quaternion p2 = new Quaternion(0, P2.X, P2.Y, P2.Z);
            Quaternion p3 = new Quaternion(0, P3.X, P3.Y, P3.Z);
            Quaternion v01 = new Quaternion(0, V01.X, V01.Y, V01.Z);
            Quaternion v02 = new Quaternion(0, V02.X, V02.Y, V02.Z);
            //
            Quaternion quaternion = qBezier(p0, p1, p2, p3, v01, v02, s, t, repS, repT);
            point = new Point3d(quaternion.B, quaternion.C, quaternion.D);
            DA.SetData(0, point);
            
        }

        private Quaternion qBezier(Quaternion p0, Quaternion p1, Quaternion p2, Quaternion p3, Quaternion v01, Quaternion v02, double s, double t, double repS, double repT)
        {
            Quaternion Id = new Quaternion(1, 0, 0, 0);
            Quaternion w1 = (p1 - p0).Inverse * v01 * repS;
            Quaternion w2 = (p2 - p0).Inverse * v02 * repT;
            Quaternion w3 = (p3 - p0).Inverse * ((p1 - p0).Inverse - (p2 - p0).Inverse) * v01 * v02 * repS * repT;
            Quaternion num = (p0 * (1 - s) + p1 * w1 * s) * (1 - t) + (p2 * w2 * (1 - s) + p3 * w3 * s) * t;
            Quaternion den = (Id * (1 - s) + w1 * s) * (1 - t) + (w2 * (1 - s) + w3 * s) * t;
            Quaternion circ = num * den.Inverse;
            return circ;
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.getdupt;
            }
        }
        public override Guid ComponentGuid => new Guid("662b6ccc-1778-4056-b2ec-91ed5ff7c7d5");
    }
}