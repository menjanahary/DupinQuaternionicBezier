﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class ImPartComponent : GH_Component
    {
        private Quaternion q;
        public ImPartComponent()
          : base(
                "ImaginaryPart",
                "Im",
                "Imaginary part of a quaternion number",
                "DupinQuaternionicBezier",
                " Tools")
        {
            q = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("A quaternion", "q", "A quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Imaginary", "q", "The imaginary part of a quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q);
            //
            Quaternion qq = (q - q.Conjugate)/2;
            //
            DA.SetData(0, qq);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.ima;
            }
        }
        public override Guid ComponentGuid => new Guid("fb6ea46a-3a16-4a96-8951-7c02d225fd2d");
    }
}