﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class ToPointComponent : GH_Component
    {
        private Quaternion q;
        public ToPointComponent()
          : base(
                "ConvertToPoint",
                "ConvPt",
                "Convert an imaginary quaternion to a Point3d",
                "DupinQuaternionicBezier",
                " Tools")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("q", "q", "A quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddPointParameter("Point", "P", "The converted point", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q);
            //
            Point3d P = new Point3d(q.B, q.C, q.D);
            //
            DA.SetData(0, P);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.toPoint;
            }
        }
        public override Guid ComponentGuid => new Guid("04b65b07-5c75-497a-8913-ebeddad9e12c");
    }
}