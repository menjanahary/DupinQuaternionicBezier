﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class InverseQuatComponent : GH_Component
    {
        private Quaternion q;
        public InverseQuatComponent()
          : base(
                "InverseQuat",
                "Inverse",
                "Inverse of a quaternion number",
                "DupinQuaternionicBezier",
                " Tools")
        {
            q = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("A quaternion", "q", "A quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Inverse", "q", "The inverse quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q);
            //
            Quaternion iq = q.Inverse;
            //
            DA.SetData(0, iq);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.inverse;
            }
        }
        public override Guid ComponentGuid => new Guid("89dd01ab-05ca-499f-ac39-2d5db39119fe");
    }
}