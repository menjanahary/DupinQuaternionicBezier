﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class CrossRatioComponent : GH_Component
    {
        private Point3d P0;
        private Point3d P1;
        private Point3d P2;
        private Point3d P3;
        public CrossRatioComponent()
          : base(
                "CrossRatio",
                "Cross",
                "Crsoss ratio between 4 points",
                "DupinQuaternionicBezier",
                " Tools")
        {
            P0 = new Point3d();
            P1 = new Point3d();
            P2 = new Point3d();
            P3 = new Point3d();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("P0", "P0", "A generic first point", GH_ParamAccess.item);
            pManager.AddPointParameter("P1", "P1", "A generic second point", GH_ParamAccess.item);
            pManager.AddPointParameter("P2", "P2", "A generic third point", GH_ParamAccess.item);
            pManager.AddPointParameter("P3", "P3", "A generic fourth point", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Cross Ratio", "cr", "The cross-ratio between 4 points", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref P0);
            DA.GetData(1, ref P1);
            DA.GetData(2, ref P2);
            DA.GetData(3, ref P3);
            //
            Quaternion p0 = new Quaternion(0, P0.X, P0.Y, P0.Z);
            Quaternion p1 = new Quaternion(0, P1.X, P1.Y, P1.Z);
            Quaternion p2 = new Quaternion(0, P2.X, P2.Y, P2.Z);
            Quaternion p3 = new Quaternion(0, P3.X, P3.Y, P3.Z);
            //
            Quaternion CR = (p0 - p1) * (p1 - p2).Inverse * (p2 - p3) * (p3 - p0).Inverse;
            DA.SetData(0, CR);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.cross;
            }
        }
        public override Guid ComponentGuid => new Guid("a06b11d9-7d8c-4850-bb12-3ba5013cbe23");
    }
}