using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class PtOnArc : GH_Component
    {

        private double u;
        private Point3d P0;
        private Point3d P1;
        private Point3d P2;
        /// <summary>
        /// Each implementation of GH_Component must provide a public 
        /// constructor without any arguments.
        /// Category represents the Tab in which the component will appear, 
        /// Subcategory the panel. If you use non-existing tab or panel names, 
        /// new tabs/panels will automatically be created.
        /// </summary>
        public PtOnArc()
          : base(
                "CirclePoint", 
                "CircPt",
                "A point on a circle defined by 3 points",
                "DupinQuaternionicBezier", 
                "Arcs")
        {
            u = 0.0;
            P0 = new Point3d();
            P1 = new Point3d();
            P2 = new Point3d();
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("P0", "P0", "First generic point", GH_ParamAccess.item);
            pManager.AddPointParameter("P1", "P1", "Second generic point", GH_ParamAccess.item);
            pManager.AddPointParameter("P2", "P2", "Third generic point", GH_ParamAccess.item);
            pManager.AddNumberParameter("Arc para", "u", "The arc parameter", GH_ParamAccess.item);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddPointParameter("P3", "P3", "An arc point", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object can be used to retrieve data from input parameters and 
        /// to store data in output parameters.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref P0);
            DA.GetData(1, ref P1);
            DA.GetData(2, ref P2);
            DA.GetData(3, ref u);
            //
            Quaternion p0 = new Quaternion(0, P0.X, P0.Y, P0.Z);
            Quaternion p1 = new Quaternion(0, P1.X, P1.Y, P1.Z);
            Quaternion p2 = new Quaternion(0, P2.X, P2.Y, P2.Z);
            //
            Quaternion Id = new Quaternion(1, 0, 0, 0);
            Quaternion weight = (p2 - p0).Inverse * (p1 - p0);
            Quaternion num = p1 * (1 - u) + (p2 * weight) * u;
            Quaternion den = Id * (1 - u) + weight * u;
            Quaternion circ = num * den.Inverse;
            Point3d P3 = new Point3d(circ.B, circ.C, circ.D);
            //
            DA.SetData(0, P3);   
        }

        /// <summary>
        /// Provides an Icon for every component that will be visible in the User Interface.
        /// Icons need to be 24x24 pixels.
        /// You can add image files to your project resources and access them like this:
        /// return Resources.IconForThisComponent;
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get 
            {
                return Properties.Resources.circP;
            }
        }

        /// <summary>
        /// Each component must have a unique Guid to identify it. 
        /// It is vital this Guid doesn't change otherwise old ghx files 
        /// that use the old ID will partially fail during loading.
        /// </summary>
        public override Guid ComponentGuid => new Guid("493cedcb-6a96-4788-a7f0-c854d98e26de");
    }
}