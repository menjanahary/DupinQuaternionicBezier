﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class GetArcPointComponent : GH_Component
    {
        private Point3d point;
        private Point3d P0;
        private Point3d P1;
        private Vector3d V01;
        private int N;
        private double rep;
        private double t;

        /// <summary>
        /// Each implementation of GH_Component must provide a public 
        /// constructor without any arguments.
        /// Category represents the Tab in which the component will appear, 
        /// Subcategory the panel. If you use non-existing tab or panel names, 
        /// new tabs/panels will automatically be created.
        /// </summary>
        public GetArcPointComponent()
          : base(
                "ArcPoint",
                "ArcPt",
                "Point on an arc defined by 2 points and a tangent vector",
                "DupinQuaternionicBezier",
                "Arcs")
        {
            point = new Point3d();
            P0 = new Point3d();
            P1 = new Point3d();
            V01 = new Vector3d();
            N = 0;
            rep = 0.0;
            t = 0.0;
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("SPoint", "S", "The start point", GH_ParamAccess.item);
            pManager.AddPointParameter("EPoint", "E", "The first point", GH_ParamAccess.item);
            pManager.AddVectorParameter("DirVec", "D", "The initial tangent vector", GH_ParamAccess.item);
            pManager.AddIntegerParameter("Subd", "N", "Number of subdivision", GH_ParamAccess.item);
            pManager.AddNumberParameter("Rep", "rep", "Reparametrization parameter", GH_ParamAccess.item);
            pManager.AddNumberParameter("t", "t", "t value", GH_ParamAccess.item);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        { 
            pManager.AddPointParameter("Point on the arc", "ArcPt", "A point on the arc", GH_ParamAccess.item);

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object can be used to retrieve data from input parameters and 
        /// to store data in output parameters.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref P0);
            DA.GetData(1, ref P1);
            DA.GetData(2, ref V01);
            DA.GetData(3, ref N);
            DA.GetData(4, ref rep);
            DA.GetData(5, ref t);
            //
            Quaternion p0 = new Quaternion(0, P0.X, P0.Y, P0.Z);
            Quaternion p1 = new Quaternion(0, P1.X, P1.Y, P1.Z);
            Quaternion v01 = new Quaternion(0, V01.X, V01.Y, V01.Z);
            //

            double u = t;
            Quaternion Id = new Quaternion(1, 0, 0, 0);
            Quaternion weight = (p1 - p0).Inverse * v01 * rep;
            Quaternion num = p0 * (1 - u) + (p1 * weight) * u;
            Quaternion den = Id * (1 - u) + weight * u;
            Quaternion circ = num * den.Inverse;
            point = new Point3d(circ.B, circ.C, circ.D);
            DA.SetData(0, point);
        }

        /// <summary>
        /// Provides an Icon for every component that will be visible in the User Interface.
        /// Icons need to be 24x24 pixels.
        /// You can add image files to your project resources and access them like this:
        /// return Resources.IconForThisComponent;
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.getpt;
            }
        }

        /// <summary>
        /// Each component must have a unique Guid to identify it. 
        /// It is vital this Guid doesn't change otherwise old ghx files 
        /// that use the old ID will partially fail during loading.
        /// </summary>
        public override Guid ComponentGuid => new Guid("56e502a8-61cd-430a-bae1-7439e52ab774");
    }
}