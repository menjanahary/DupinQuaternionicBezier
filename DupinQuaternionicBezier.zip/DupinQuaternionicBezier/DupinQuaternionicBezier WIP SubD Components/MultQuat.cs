﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class MultQuatComponent : GH_Component
    {
        private Quaternion q1;
        private Quaternion q2;
        public MultQuatComponent()
          : base(
                " MultQuat",
                "Mult",
                "Multiply two quaternion numbers",
                "DupinQuaternionicBezier",
                " Operations")
        {
            q1 = new Quaternion();
            q2 = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("First quaternion", "q1", "First quaternion", GH_ParamAccess.item);
            pManager.AddGenericParameter("Second quaternion", "q2", "Second quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Quaternion", "q", "The resulting quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q1);
            DA.GetData(1, ref q2);
            //
            Quaternion q = q1 * q2;
            //
            DA.SetData(0, q);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.mult;
            }
        }
        public override Guid ComponentGuid => new Guid("cdb28957-83d6-47d4-a3b1-e386d922891e");
    }
}