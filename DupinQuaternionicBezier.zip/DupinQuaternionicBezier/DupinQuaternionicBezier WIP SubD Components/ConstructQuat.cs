﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class ConstructQuatComponent : GH_Component
    {
        private double r;
        private double x;
        private double y;
        private double z;
        public ConstructQuatComponent()
          : base(
                "ConstructQuat",
                "Quat",
                "Construct a quaternion number",
                "DupinQuaternionicBezier",
                " Tools")
        {
            r = 0.0; x = 0.0; y = 0.0; z = 0.0;
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddNumberParameter("r", "r", "The real part", GH_ParamAccess.item, 0.0);
            pManager.AddNumberParameter("x", "x", "X coordinate", GH_ParamAccess.item, 0.0);
            pManager.AddNumberParameter("y", "y", "Y coordinate", GH_ParamAccess.item, 0.0);
            pManager.AddNumberParameter("z", "z", "Z coordinate", GH_ParamAccess.item, 0.0);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Quaternion", "q", "The resulting quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref r);
            DA.GetData(1, ref x);
            DA.GetData(2, ref y);
            DA.GetData(3, ref z);
            //
            Quaternion q = new Quaternion(r, x, y, z);
            //
            DA.SetData(0, q);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.quat;
            }
        }
        public override Guid ComponentGuid => new Guid("b01429c8-8108-44cc-882b-60a58a9ff344");
    }
}