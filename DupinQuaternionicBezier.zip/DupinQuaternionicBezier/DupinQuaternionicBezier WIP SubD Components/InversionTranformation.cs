﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class InversionTransformationComponent : GH_Component
    {
        private double r;
        private Quaternion q0;
        private Quaternion q;
        public InversionTransformationComponent()
          : base(
                "Inversion",
                "Inversion",
                "Inversion with respect to a sphere",
                "DupinQuaternionicBezier",
                " Tools")
        {
            r = 0.0;
            q0 = new Quaternion();
            q = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddNumberParameter("Radius", "r", "The radius of the sphere of inversion", GH_ParamAccess.item);
            pManager.AddGenericParameter("Quaternion", "q0", "The center of inversion as a quaternion", GH_ParamAccess.item);
            pManager.AddGenericParameter("Quaternion", "q", "The quaternion to invert", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Q", "Q", "The inverted quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {

            DA.GetData(0, ref r);
            DA.GetData(1, ref q0);
            DA.GetData(2, ref q);
            Quaternion resultQuaternion = q0 - (q - q0).Inverse * r * r;
            DA.SetData(0, resultQuaternion);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.inv;
            }
        }
        public override Guid ComponentGuid => new Guid("f76799ff-6581-4701-a205-88beb1720edf");
    }
}