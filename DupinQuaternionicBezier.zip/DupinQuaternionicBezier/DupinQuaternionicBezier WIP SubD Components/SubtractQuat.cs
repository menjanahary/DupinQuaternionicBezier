﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class SubtractQuatComponent : GH_Component
    {
        private Quaternion q1;
        private Quaternion q2;
        public SubtractQuatComponent()
          : base(
                "  SubQuat",
                "Sub",
                "Subtract two quaternion numbers",
                "DupinQuaternionicBezier",
                " Operations")
        {
            q1 = new Quaternion();
            q2 = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("First quaternion", "q1", "First quaternion", GH_ParamAccess.item);
            pManager.AddGenericParameter("Second quaternion", "q2", "Second quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Quaternion", "q", "The resulting quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q1);
            DA.GetData(1, ref q2);
            //
            Quaternion q = q1 - q2;
            //
            DA.SetData(0, q);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.sub;
            }
        }
        public override Guid ComponentGuid => new Guid("a787999e-a69b-4a2b-b505-53d897970de7");
    }
}