﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class NormQuatComponent : GH_Component
    {
        private Quaternion q;
        public NormQuatComponent()
          : base(
                "NormQuat",
                "Norm",
                "Squared norm of a quaternion number",
                "DupinQuaternionicBezier",
                " Tools")
        {
            q = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("A quaternion", "q", "A quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("Norm", "L", "The squared norm of a quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q);
            //
            Quaternion qq = q * q.Conjugate;
            //
            DA.SetData(0, qq.A);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.norm;
            }
        }
        public override Guid ComponentGuid => new Guid("ca002b17-3066-41cb-91d0-c39c66964ee8");
    }
}