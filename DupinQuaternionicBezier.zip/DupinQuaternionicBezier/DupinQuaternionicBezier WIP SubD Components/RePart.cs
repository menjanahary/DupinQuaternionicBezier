﻿using Grasshopper;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace DupinQuaternionicBezier
{
    public class RePartComponent : GH_Component
    {
        private Quaternion q;
        public RePartComponent()
          : base(
                "RealPart",
                "Re",
                "Real part of a quaternion number",
                "DupinQuaternionicBezier",
                " Tools")
        {
            q = new Quaternion();
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("A quaternion", "q", "A quaternion", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("RealPart", "r", "The real part of a quaternion", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            DA.GetData(0, ref q);
            //
            double r = q.A;
            //
            DA.SetData(0, r);
        }
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.re;
            }
        }
        public override Guid ComponentGuid => new Guid("b1f3afc3-9220-4da5-83ec-ae0be326c8f6");
    }
}